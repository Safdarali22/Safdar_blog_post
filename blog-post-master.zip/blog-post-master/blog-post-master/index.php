<?php
session_start();

require_once 'utilities/user.php';

$user_name = "";
$login_fail_message = ""; 

if(isset($_POST['user-name'])) {
	$user_name = $_POST['user-name'];
	$user_pass = $_POST['user-pass'];

	$user = do_login($user_name, $user_pass);
	
	if($user != null) {
		$_SESSION["_user"] = $user;
		header("Location: home.php");
	}
	$login_fail_message = "Username or password mismatched";
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<link rel="stylesheet" href="style.css">
		<title>Main</title>
		<style>
        /* Copy and paste the CSS code here */
		/* Reset some default styles */
body, h1, p, label, input {
    margin: 0;
    padding: 0;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    text-align: center;
}

/* Header Styles (You may customize this based on your header structure) */
header {
    background-color: #333;
    color: #fff;
    padding: 10px;
}

/* Form Styles */
h1 {
    color: #333;
    margin-bottom: 20px;
}

form {
    max-width: 300px;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

label {
    display: block;
    margin-bottom: 10px;
    color: #333;
}

input {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 3px;
}

input[type="submit"] {
    background-color: #333;
    color: #fff;
    cursor: pointer;
}

.error-message {
    color: #f00;
    margin-bottom: 10px;
}

    </style>
	</head>
	<body>
		<?php include "header.php";?>
		<div style="text-align: center">
			<h1>Login Form</h1>
			<?php if($login_fail_message):?>
			<div class="error-message"><?=$login_fail_message;?></div>
			<?php endif;?>

			<form method="POST" action="<?=$_SERVER['PHP_SELF']?>">
				<div>
					<label
						>User Name
						<input type="text" name="user-name" value="<?=$user_name?>" required />
					</label>
				</div>
				<div>
					<label
						>User Password
						<input type="password" name="user-pass" required />
					</label>
				</div>
				<div>
					<input type="submit" value="Submit" />
				</div>
			</form>
		</div>
	</body>
</html>

